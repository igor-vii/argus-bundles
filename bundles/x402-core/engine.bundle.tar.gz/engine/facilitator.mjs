// Argus engine — facilitator counterpart, shipped inside the sealed bundle.
//
// Implements the x402 verify/settle contract with honest nonces (a nonce is
// burned only by a successful settle) plus session-scoped fault injection
// points driven exclusively by the engine harness over /admin endpoints.
import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import { CHALLENGE_AMOUNT, RESOURCE_PATH, verifyPaymentSignature } from './protocol.mjs';

export function createFacilitator({ port, log = () => {} }) {
  const usedNonces = new Set(); // honest nonces: burned on settle, not on verify
  const injections = new Map(); // session_id -> { mode }
  const receipts = new Map(); // settle_id -> receipt
  const callLog = []; // every verify/settle attempt; the engine's oracle

  function takeInjection(sessionId, expectedMode) {
    if (!sessionId) return null;
    const inj = injections.get(sessionId);
    if (inj && inj.mode === expectedMode) {
      injections.delete(sessionId);
      return inj;
    }
    return null;
  }

  function verifyInternal(payment, sessionId) {
    const inj = takeInjection(sessionId, 'verify_503');
    callLog.push({
      kind: 'verify',
      session_id: sessionId,
      challenge_id: payment?.challenge_id ?? null,
      nonce: payment?.nonce ?? null,
      amount: payment?.amount ?? null,
    });
    if (inj) return { status: 503, body: { ok: false, code: 'verify_unavailable' } };
    if (!payment || !payment.nonce || !payment.sig_b64 || !payment.client_pubkey_b64) {
      return { status: 200, body: { ok: false, code: 'malformed' } };
    }
    if (!verifyPaymentSignature(payment)) return { status: 200, body: { ok: false, code: 'bad_signature' } };
    if (String(payment.amount) !== CHALLENGE_AMOUNT) {
      return { status: 200, body: { ok: false, code: 'amount_mismatch' } };
    }
    if (payment.resource !== RESOURCE_PATH) {
      return { status: 200, body: { ok: false, code: 'unknown_resource' } };
    }
    if (usedNonces.has(payment.nonce)) return { status: 200, body: { ok: false, code: 'nonce_reused' } };
    return {
      status: 200,
      body: { ok: true, receipt: { verify_id: 'v-' + randomBytes(8).toString('hex'), nonce: payment.nonce } },
    };
  }

  function settleInternal(payment, sessionId) {
    const inj = takeInjection(sessionId, 'settle_fail');
    callLog.push({
      kind: 'settle',
      session_id: sessionId,
      challenge_id: payment?.challenge_id ?? null,
      nonce: payment?.nonce ?? null,
      amount: payment?.amount ?? null,
    });
    if (inj) return { status: 200, body: { ok: false, code: 'settle_failed' } };
    if (!verifyPaymentSignature(payment)) return { status: 200, body: { ok: false, code: 'bad_signature' } };
    if (usedNonces.has(payment.nonce)) return { status: 200, body: { ok: false, code: 'nonce_reused' } };
    usedNonces.add(payment.nonce);
    const settle = {
      settle_id: 's-' + randomBytes(8).toString('hex'),
      nonce: payment.nonce,
      amount: payment.amount,
      challenge_id: payment.challenge_id ?? null,
      settled_at: new Date().toISOString(),
    };
    receipts.set(settle.settle_id, settle);
    return { status: 200, body: { ok: true, settle } };
  }

  const server = createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => {
      raw += c;
    });
    req.on('end', () => {
      let body = {};
      try {
        body = raw ? JSON.parse(raw) : {};
      } catch {
        body = {};
      }
      const path = (req.url || '/').split('?')[0];
      const sessionId = req.headers['x-argus-session'] || body.session_id || null;
      const reply = (status, obj) => {
        res.statusCode = status;
        res.setHeader('content-type', 'application/json');
        res.end(JSON.stringify(obj));
      };
      const payment = body.payment || body;

      if (req.method === 'GET' && path === '/health') return reply(200, { ok: true, role: 'facilitator' });
      if (req.method === 'POST' && path === '/verify') return reply(200, verifyInternal(payment, sessionId).body);
      if (req.method === 'POST' && path === '/settle') return reply(200, settleInternal(payment, sessionId).body);
      if (req.method === 'POST' && path === '/submit') {
        // Buyer-initiated path (S-BS family): verify + settle in one round trip.
        const v = verifyInternal(payment, sessionId);
        if (!v.body.ok) return reply(v.status, v.body);
        const s = settleInternal(payment, sessionId);
        if (!s.body.ok) return reply(200, s.body);
        return reply(200, { ok: true, receipt: s.body.settle });
      }
      if (req.method === 'GET' && path.startsWith('/receipts/')) {
        const id = decodeURIComponent(path.slice('/receipts/'.length));
        const r = receipts.get(id);
        return r ? reply(200, { ok: true, receipt: r }) : reply(200, { ok: false, code: 'unknown_receipt' });
      }
      if (req.method === 'POST' && path === '/admin/inject') {
        if (!body.session_id || !body.mode) return reply(400, { ok: false, error: 'session_id and mode required' });
        injections.set(body.session_id, { mode: body.mode });
        return reply(200, { ok: true });
      }
      if (req.method === 'GET' && path === '/admin/call-log') return reply(200, { ok: true, calls: callLog });
      if (req.method === 'POST' && path === '/admin/reset') {
        usedNonces.clear();
        injections.clear();
        receipts.clear();
        callLog.length = 0;
        return reply(200, { ok: true });
      }
      return reply(404, { ok: false, error: 'not_found' });
    });
  });

  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', () => {
      log(`facilitator listening on 127.0.0.1:${port}`);
      resolve({
        server,
        port,
        callLog,
        close: () => new Promise((r) => server.close(r)),
      });
    });
  });
}
