#!/usr/bin/env node
// Argus engine entrypoint. Ships inside the sealed bundle; the action executes
// it against the SUT started from argus.sut.json.
//
// Scenario families (lab registry): S-BS (s8) — Argus as the bad seller,
// BC (s9) — Argus as the bad client. The family is selected by the SUT role:
// role "seller" (default) runs BC, role "client" runs S-BS.
import { parseArgs } from 'node:util';
import fs from 'node:fs';
import path from 'node:path';
import { createFacilitator } from './facilitator.mjs';
import { applyMatchers } from './matchers.mjs';
import { createClientWallet, HarnessError } from './protocol.mjs';
import { FAMILY as BC_FAMILY, SESSIONS as BC_SESSIONS, createHttpContext } from './batteries/x402-core/bc.sessions.mjs';
import { FAMILY as BS_FAMILY, SCENARIOS as BS_SCENARIOS, createBadSeller, createCanary } from './batteries/x402-core/bs.scenarios.mjs';

const SEVERITY = { PASS: 0, DOCUMENTED: 1, FAIL: 2, HARNESS_ERROR: 3 };

function fail(message) {
  throw new HarnessError(message);
}

async function healthGate(base) {
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    try {
      const r = await fetch(base + '/health', { signal: AbortSignal.timeout(2000) });
      if (r.ok) return;
    } catch {
      /* retry */
    }
    await new Promise((r) => setTimeout(r, 300));
  }
  fail(`health gate failed: ${base}/health did not become ready`);
}

async function facilitatorInject(port, sessionId, mode) {
  await fetch(`http://127.0.0.1:${port}/admin/inject`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ session_id: sessionId, mode }),
    signal: AbortSignal.timeout(5000),
  });
}

async function runSession(result, workspace, batteryId, family, session, exec) {
  const started = Date.now();
  const lines = [];
  const ledger = {
    append: (event, data) => lines.push({ ts: new Date().toISOString(), session_id: session.id, event, ...data }),
  };
  let outcome;
  try {
    outcome = await exec({ ledger, sessionId: session.id });
  } catch (err) {
    outcome = { verdict: 'HARNESS_ERROR', refusal: null, note: String(err?.message ?? err) };
  }
  outcome = applyMatchers(outcome, lines);
  ledger.append('verdict', { verdict: outcome.verdict, refusal: outcome.refusal ?? null, note: outcome.note ?? null });
  const rel = path.join('ledgers', batteryId, `${session.id}-${session.name}.jsonl`);
  const abs = path.join(workspace, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, lines.map((l) => JSON.stringify(l)).join('\n') + '\n');
  result.verdicts.push({
    session_id: session.id,
    family,
    name: session.name,
    verdict: outcome.verdict,
    refusal: outcome.refusal ?? null,
    note: outcome.note ?? null,
    duration_ms: Date.now() - started,
    evidence: rel,
  });
  result.ledgers.push(rel);
  console.log(`engine | ${session.id} ${session.name} -> ${outcome.verdict}${outcome.note ? ` (${outcome.note})` : ''}`);
}

async function main() {
  const args = parseArgs({
    options: {
      sut: { type: 'string' },
      workspace: { type: 'string' },
      mode: { type: 'string', default: 'ci-local' },
      'engine-version': { type: 'string', default: '0.0.0' },
      'bundle-key-id': { type: 'string', default: '' },
      'bundle-sha256': { type: 'string', default: '' },
    },
  });

  const workspace = path.resolve(args.values.workspace);
  const contract = JSON.parse(fs.readFileSync(path.resolve(args.values.sut), 'utf8'));
  if (contract.schema !== 'argus.sut.v0') fail(`unsupported SUT contract schema: ${contract.schema}`);

  const role = contract.role ?? 'seller';
  const rail = contract.payment?.rail ?? 'local';
  const batteryId = contract.battery || 'x402-core';

  const result = {
    schema: 'argus.result.v0',
    mode: args.values.mode,
    battery: batteryId,
    role,
    payment_rail: rail,
    engine_version: args.values['engine-version'],
    bundle: { key_id: args.values['bundle-key-id'], tree_sha256: args.values['bundle-sha256'] },
    started_at: new Date().toISOString(),
    duration_ms: 0,
    rollup: 'HARNESS_ERROR',
    verdicts: [],
    ledgers: [],
    seal: { eligible: true, sealed: false },
  };

  const t0 = Date.now();
  const finish = (code) => {
    result.duration_ms = Date.now() - t0;
    result.rollup = result.verdicts.reduce(
      (m, v) => (SEVERITY[v.verdict] > SEVERITY[m] ? v.verdict : m),
      result.verdicts.length ? 'PASS' : 'HARNESS_ERROR',
    );
    fs.writeFileSync(path.join(workspace, 'argus-result.json'), JSON.stringify(result, null, 2));
    console.log(`engine | battery ${batteryId}: ${result.verdicts.length} sessions, rollup ${result.rollup}`);
    process.exit(code);
  };

  let facilitator = null;
  try {
    if (rail !== 'local') {
      fail(
        `payment rail "${rail}" is not wired into ci-local runs yet (base-sepolia rail is planned); ` +
          'set payment.rail to "local" or drop the payment block',
      );
    }

    const facilitatorUrl = contract.env?.FACILITATOR_URL || 'http://127.0.0.1:5060';
    const facPort = Number(new URL(facilitatorUrl).port) || 5060;
    facilitator = await createFacilitator({ port: facPort, log: (m) => console.log('engine | ' + m) });

    if (role === 'seller') {
      // SUT is the seller; Argus probes it as the bad client (BC family).
      const sutBase = new URL(contract.ready.url).origin;
      await healthGate(sutBase);
      const wallet = createClientWallet();
      const shared = {};
      for (const session of BC_SESSIONS) {
        await runSession(result, workspace, batteryId, BC_FAMILY, session, ({ ledger, sessionId }) => {
          const ctx = {
            sutBase,
            wallet,
            shared,
            http: createHttpContext({ sutBase, ledger, sessionId }),
            facilitator: { inject: (mode) => facilitatorInject(facPort, sessionId, mode) },
          };
          return session.run(ctx);
        });
      }
    } else if (role === 'client') {
      // SUT is the buyer; Argus plays the bad seller (S-BS family).
      const sellerUrl = contract.env?.SELLER_URL;
      if (!sellerUrl) fail('role "client" requires env.SELLER_URL in the SUT contract');
      const seller = await createBadSeller({
        port: Number(new URL(sellerUrl).port) || 5090,
        facilitatorPort: facPort,
        log: (m) => console.log('engine | ' + m),
      });
      const canary = await createCanary({ log: (m) => console.log('engine | ' + m) });
      seller.setCanaryUrl(canary.url);
      try {
        const buyerBase = new URL(contract.ready.url).origin;
        await healthGate(buyerBase);
        for (const scenario of BS_SCENARIOS) {
          await runSession(result, workspace, batteryId, BS_FAMILY, scenario, ({ ledger }) => {
            const t = {
              seller,
              canary,
              facilitator,
              buyerBase,
              ledger,
              runBuyer: async () => {
                const r = await fetch(buyerBase + '/run', {
                  method: 'POST',
                  headers: { 'content-type': 'application/json' },
                  body: JSON.stringify({ once: true }),
                  signal: AbortSignal.timeout(20000),
                });
                const body = await r.json().catch(() => ({}));
                return body?.entry ?? null;
              },
            };
            return scenario.run(t);
          });
        }
      } finally {
        await canary.close();
        await seller.close();
      }
    } else {
      fail(`unsupported SUT role: ${role}`);
    }
    finish(0);
  } catch (err) {
    console.error('engine | harness error:', err?.message ?? err);
    result.harness_error = { message: String(err?.message ?? err) };
    finish(3);
  } finally {
    if (facilitator) await facilitator.close().catch(() => {});
  }
}

main();
