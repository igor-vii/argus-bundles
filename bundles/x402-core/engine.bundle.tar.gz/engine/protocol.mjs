// Argus engine — x402-shaped payment rail (local, deterministic).
//
// Mirrors the EIP-3009 authorize -> facilitator verify -> settle shape so the
// on-chain Base Sepolia rail can replace it later without touching scenario
// code. Scenario families are rail-agnostic: they assert on challenge shape,
// verify/settle semantics and nonce honesty, not on the crypto curve.
//
// Rails:
//   local        — Ed25519 demo authorization, deterministic, CI-safe (default)
//   base-sepolia — planned; the engine rejects it in ci-local runs for now
import { createPublicKey, sign as edSign, verify as edVerify, generateKeyPairSync } from 'node:crypto';

export const RAILS = ['local'];
export const CHALLENGE_AMOUNT = '10000'; // demo ledger units
export const PROTOCOL_VERSION = 1;
export const RESOURCE_PATH = '/resource';
export const RESOURCE_TOKEN = 'demo-resource-ok';
export const REFUSAL_CODES = [
  // facilitator-side codes
  'nonce_reused',
  'bad_signature',
  'amount_mismatch',
  'settle_failed',
  'verify_unavailable',
  'unknown_resource',
  'malformed',
  'invalid_receipt',
  // buyer-side guard codes (S-BS family)
  'amount_exceeds_challenge',
  'malformed_challenge',
  'untrusted_facilitator',
  'unsupported_version',
  'duplicate_offer',
  'unverified_receipt',
  'additional_payment_demand',
];

export class HarnessError extends Error {}

// Deterministic canonical JSON (sorted keys, no whitespace) — the signing
// format shared by the engine, the CI packer and the action verifier.
export function canonical(obj) {
  if (obj === null || typeof obj !== 'object' || Array.isArray(obj)) {
    return JSON.stringify(obj) ?? 'null';
  }
  const keys = Object.keys(obj).sort();
  return '{' + keys.map((k) => JSON.stringify(k) + ':' + canonical(obj[k])).join(',') + '}';
}

export function canonicalPayment(p) {
  return JSON.stringify({ amount: p.amount, challenge_id: p.challenge_id, nonce: p.nonce, resource: p.resource });
}

export function createClientWallet() {
  const { publicKey, privateKey } = generateKeyPairSync('ed25519');
  return {
    privateKey,
    publicKeyB64: publicKey.export({ type: 'spki', format: 'der' }).toString('base64'),
  };
}

export function signPayment(privateKey, payment) {
  const sig = edSign(null, Buffer.from(canonicalPayment(payment)), privateKey);
  return Buffer.from(sig).toString('base64');
}

export function buildPayment(wallet, { challenge_id, amount, resource, nonce }) {
  const payment = {
    challenge_id,
    nonce,
    amount: String(amount),
    resource,
    client_pubkey_b64: wallet.publicKeyB64,
    sig_b64: '',
  };
  payment.sig_b64 = signPayment(wallet.privateKey, payment);
  return payment;
}

export function verifyPaymentSignature(payment) {
  try {
    const pub = createPublicKey({
      key: Buffer.from(payment.client_pubkey_b64, 'base64'),
      type: 'spki',
      format: 'der',
    });
    const sig = Buffer.from(payment.sig_b64, 'base64');
    return edVerify(null, Buffer.from(canonicalPayment(payment)), pub, sig);
  } catch {
    return false;
  }
}

export function encodePaymentHeader(payment) {
  return Buffer.from(JSON.stringify(payment), 'utf8').toString('base64');
}

export function decodePaymentHeader(header) {
  try {
    return JSON.parse(Buffer.from(header, 'base64').toString('utf8'));
  } catch {
    return null;
  }
}
