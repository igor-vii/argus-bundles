// S-BS family (lab registry alias: s8/S-BS) — Argus plays the BAD SELLER.
// The SUT is the buyer (contract role "client"); the engine hosts a poisoned
// seller plus the trusted facilitator and an attacker-facilitator canary.
// Assertions run on two oracles the engine fully controls: the facilitator
// call log and the buyer's per-offer report.
import { createServer } from 'node:http';
import { randomBytes } from 'node:crypto';
import { CHALLENGE_AMOUNT, decodePaymentHeader, RESOURCE_TOKEN } from '../../protocol.mjs';

export const FAMILY = 'S-BS';

function reply(res, status, obj) {
  res.statusCode = status;
  res.setHeader('content-type', 'application/json');
  res.end(JSON.stringify(obj));
}

// Attacker facilitator: records any payment the naive buyer sends to it.
export function createCanary({ log = () => {} } = {}) {
  let hits = 0;
  const server = createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => {
      raw += c;
    });
    req.on('end', () => {
      hits += 1;
      log(`canary captured request #${hits} ${req.method} ${req.url}`);
      let payment = {};
      try {
        const body = JSON.parse(raw || '{}');
        payment = body?.payment ?? {};
      } catch {
        /* fall back to header */
      }
      if (!payment?.nonce) payment = decodePaymentHeader(req.headers['x-payment'] || '') || {};
      reply(res, 200, {
        ok: true,
        receipt: { settle_id: 'attacker-' + randomBytes(4).toString('hex'), nonce: payment.nonce ?? null },
      });
    });
  });
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      log(`canary listening on 127.0.0.1:${port}`);
      resolve({
        server,
        url: `http://127.0.0.1:${port}`,
        hits: () => hits,
        resetHits: () => {
          hits = 0;
        },
        close: () => new Promise((r) => server.close(r)),
      });
    });
  });
}

export function createBadSeller({ port, facilitatorPort, log = () => {} }) {
  const facilitatorUrl = `http://127.0.0.1:${facilitatorPort}`;
  let offerCounter = 0;
  let offerPoison = null; // 'malformed' | 'downgrade' | 'untrusted' | {duplicate, challenge_id}
  let deliverPoison = null; // 'inflate_retry' | 'forged_receipt'

  const server = createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => {
      raw += c;
    });
    req.on('end', async () => {
      const path = (req.url || '/').split('?')[0];
      if (req.method === 'GET' && path === '/health') return reply(res, 200, { ok: true, role: 'seller' });

      if (req.method === 'GET' && path === '/offer') {
        const poison = offerPoison;
        offerPoison = null;
        if (poison === 'malformed') {
          return reply(res, 402, {
            x402: { version: 1, challenge_id: 'bs-ch-' + ++offerCounter, resource: '/resource', facilitator_url: facilitatorUrl },
          });
        }
        if (poison === 'downgrade') {
          return reply(res, 402, {
            x402: { version: 0, challenge_id: 'bs-ch-' + ++offerCounter, resource: '/resource', amount: CHALLENGE_AMOUNT, facilitator_url: facilitatorUrl },
          });
        }
        if (poison === 'untrusted') {
          return reply(res, 402, {
            x402: {
              version: 1,
              challenge_id: 'bs-ch-' + ++offerCounter,
              resource: '/resource',
              amount: CHALLENGE_AMOUNT,
              facilitator_url: canaryUrl,
            },
          });
        }
        if (poison && typeof poison === 'object' && poison.offer === 'duplicate') {
          return reply(res, 402, {
            x402: {
              version: 1,
              challenge_id: poison.challenge_id,
              resource: '/resource',
              amount: CHALLENGE_AMOUNT,
              facilitator_url: facilitatorUrl,
            },
          });
        }
        return reply(res, 402, {
          x402: {
            version: 1,
            challenge_id: 'bs-ch-' + ++offerCounter,
            resource: '/resource',
            amount: CHALLENGE_AMOUNT,
            facilitator_url: facilitatorUrl,
          },
        });
      }

      if (req.method === 'POST' && path === '/deliver') {
        const receipt = decodePaymentHeader(req.headers['x-payment-receipt'] || '');
        if (!receipt?.settle?.settle_id || !receipt?.payment) {
          return reply(res, 402, { refusal: { code: 'invalid_receipt' } });
        }
        // The seller always re-checks the receipt against the facilitator.
        const check = await fetch(`${facilitatorUrl}/receipts/${encodeURIComponent(receipt.settle.settle_id)}`, {
          signal: AbortSignal.timeout(5000),
        });
        const checkBody = await check.json().catch(() => ({}));
        if (!checkBody?.ok || checkBody.receipt?.nonce !== receipt.payment.nonce) {
          return reply(res, 402, { refusal: { code: 'invalid_receipt' } });
        }
        const poison = deliverPoison;
        deliverPoison = null;
        if (poison === 'inflate_retry') {
          // Seller claims settle failed and demands MORE money for the same offer.
          return reply(res, 402, {
            x402: {
              version: 1,
              challenge_id: receipt.payment.challenge_id,
              resource: '/resource',
              amount: '20000',
              facilitator_url: facilitatorUrl,
            },
            refusal: { code: 'settle_failed' },
          });
        }
        if (poison === 'forged_receipt') {
          // Seller delivers the resource but hands over a receipt the
          // facilitator does not know. The buyer must catch this.
          return reply(res, 200, {
            resource: RESOURCE_TOKEN,
            settle: { settle_id: 'fake-' + randomBytes(4).toString('hex'), nonce: receipt.payment.nonce },
          });
        }
        return reply(res, 200, { resource: RESOURCE_TOKEN, settle: receipt.settle });
      }

      if (req.method === 'POST' && path === '/admin/configure') {
        let body = {};
        try {
          body = JSON.parse(raw || '{}');
        } catch {
          /* ignore */
        }
        offerPoison = body.offer ?? null;
        deliverPoison = body.deliver ?? null;
        return reply(res, 200, { ok: true });
      }
      return reply(res, 404, { ok: false, error: 'not_found' });
    });
  });

  let canaryUrl = '';
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', () => {
      log(`bad seller listening on 127.0.0.1:${port}`);
      resolve({
        server,
        port,
        adminConfigure: (cfg) => {
          offerPoison =
            cfg.offer === 'duplicate'
              ? { offer: 'duplicate', challenge_id: cfg.challenge_id }
              : (cfg.offer ?? null);
          deliverPoison = cfg.deliver ?? null;
        },
        setCanaryUrl: (u) => {
          canaryUrl = u;
        },
        close: () => new Promise((r) => server.close(r)),
      });
    });
  });
}

// Scenario runner context:
//   t = { seller, canary, facilitator, buyerBase, ledger, runBuyer() -> entry }
export const SCENARIOS = [
  { id: 'bs-01', name: 'inflated-retry-refused', run: inflatedRetry },
  { id: 'bs-02', name: 'duplicate-challenge-refused', run: duplicateChallenge },
  { id: 'bs-03', name: 'malformed-challenge-refused', run: malformedChallenge },
  { id: 'bs-04', name: 'untrusted-facilitator-refused', run: untrustedFacilitator },
  { id: 'bs-05', name: 'forged-receipt-unaccepted', run: forgedReceipt },
  { id: 'bs-06', name: 'downgrade-protocol-refused', run: downgradeProtocol },
];

async function inflatedRetry(t) {
  t.seller.adminConfigure({ deliver: 'inflate_retry' });
  const before = t.facilitator.callLog.length;
  const entry = await t.runBuyer();
  const calls = t.facilitator.callLog.slice(before);
  t.ledger.append('buyer', { entry });
  t.ledger.append('facilitator_calls', { calls });
  if (calls.some((c) => c.kind === 'verify' && String(c.amount) === '20000')) {
    return { verdict: 'FAIL', refusal: null, note: 'buyer attempted to pay the inflated 20000 demand' };
  }
  if (entry?.outcome !== 'refused') {
    return { verdict: 'FAIL', refusal: null, note: `buyer accepted the additional payment demand (outcome=${entry?.outcome})` };
  }
  return { verdict: 'DOCUMENTED', refusal: { code: entry.refusal_code || 'amount_exceeds_challenge' }, note: null };
}

async function duplicateChallenge(t) {
  t.seller.adminConfigure({});
  const before = t.facilitator.callLog.length;
  const first = await t.runBuyer();
  t.ledger.append('buyer', { entry: first });
  if (first?.outcome !== 'paid') {
    return { verdict: 'HARNESS_ERROR', refusal: null, note: `baseline purchase failed (${first?.outcome}/${first?.refusal_code})` };
  }
  t.seller.adminConfigure({ offer: 'duplicate', challenge_id: first.challenge_id });
  const second = await t.runBuyer();
  t.ledger.append('buyer', { entry: second });
  const calls = t.facilitator.callLog.slice(before);
  t.ledger.append('facilitator_calls', { calls });
  const paysForDuplicate = calls.filter((c) => c.challenge_id === first.challenge_id).length > 2;
  if (paysForDuplicate) return { verdict: 'FAIL', refusal: null, note: 'buyer paid twice for the same challenge_id' };
  if (second?.outcome !== 'refused') {
    return { verdict: 'FAIL', refusal: null, note: 'buyer did not refuse the duplicated challenge' };
  }
  return { verdict: 'DOCUMENTED', refusal: { code: second.refusal_code || 'duplicate_offer' }, note: null };
}

async function malformedChallenge(t) {
  t.seller.adminConfigure({ offer: 'malformed' });
  const before = t.facilitator.callLog.length;
  const entry = await t.runBuyer();
  const calls = t.facilitator.callLog.slice(before);
  t.ledger.append('buyer', { entry });
  t.ledger.append('facilitator_calls', { calls });
  if (calls.length > 0) {
    return { verdict: 'FAIL', refusal: null, note: 'buyer contacted the facilitator over a malformed challenge' };
  }
  if (entry?.outcome !== 'refused') {
    return { verdict: 'FAIL', refusal: null, note: 'buyer did not refuse the malformed challenge' };
  }
  return { verdict: 'DOCUMENTED', refusal: { code: entry.refusal_code || 'malformed_challenge' }, note: null };
}

async function untrustedFacilitator(t) {
  t.seller.adminConfigure({ offer: 'untrusted' });
  const before = t.facilitator.callLog.length;
  t.canary.resetHits();
  const entry = await t.runBuyer();
  const calls = t.facilitator.callLog.slice(before);
  const hits = t.canary.hits();
  t.ledger.append('buyer', { entry });
  t.ledger.append('facilitator_calls', { calls });
  t.ledger.append('canary', { hits });
  if (hits > 0) {
    return { verdict: 'FAIL', refusal: null, note: `buyer leaked payment to the attacker facilitator (${hits} hit)` };
  }
  if (calls.length > 0) {
    return { verdict: 'FAIL', refusal: null, note: 'buyer used the trusted facilitator for an untrusted challenge' };
  }
  if (entry?.outcome !== 'refused') {
    return { verdict: 'FAIL', refusal: null, note: 'buyer did not refuse the untrusted facilitator' };
  }
  return { verdict: 'DOCUMENTED', refusal: { code: entry.refusal_code || 'untrusted_facilitator' }, note: null };
}

async function forgedReceipt(t) {
  t.seller.adminConfigure({ deliver: 'forged_receipt' });
  const entry = await t.runBuyer();
  t.ledger.append('buyer', { entry });
  if (entry?.outcome === 'paid') {
    return { verdict: 'FAIL', refusal: null, note: 'buyer accepted a settle receipt unknown to the facilitator' };
  }
  if (entry?.outcome !== 'refused') {
    return { verdict: 'HARNESS_ERROR', refusal: null, note: `unexpected buyer outcome: ${entry?.outcome}` };
  }
  return { verdict: 'DOCUMENTED', refusal: { code: entry.refusal_code || 'unverified_receipt' }, note: null };
}

async function downgradeProtocol(t) {
  t.seller.adminConfigure({ offer: 'downgrade' });
  const before = t.facilitator.callLog.length;
  const entry = await t.runBuyer();
  const calls = t.facilitator.callLog.slice(before);
  t.ledger.append('buyer', { entry });
  t.ledger.append('facilitator_calls', { calls });
  if (calls.length > 0) {
    return { verdict: 'FAIL', refusal: null, note: 'buyer paid a downgrade (version 0) challenge' };
  }
  if (entry?.outcome !== 'refused') {
    return { verdict: 'FAIL', refusal: null, note: 'buyer did not refuse the downgrade challenge' };
  }
  return { verdict: 'DOCUMENTED', refusal: { code: entry.refusal_code || 'unsupported_version' }, note: null };
}
