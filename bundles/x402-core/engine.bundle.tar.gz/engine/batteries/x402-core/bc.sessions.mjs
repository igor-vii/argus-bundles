// BC family (lab registry alias: s9/BC) — Argus plays the BAD CLIENT/buyer
// probing the SUT, which acts as the seller. SUT contract role: "seller"
// (default). Nine core sessions, rail-agnostic.
import { randomBytes } from 'node:crypto';
import { buildPayment, encodePaymentHeader, RESOURCE_PATH, RESOURCE_TOKEN } from '../../protocol.mjs';

export const FAMILY = 'BC';

export const SESSIONS = [
  { id: 'bc-01', name: 'challenge-gate', run: challengeGate },
  { id: 'bc-02', name: 'valid-payment-served', run: validPaymentServed },
  { id: 'bc-03', name: 'replay-refused', run: replayRefused },
  { id: 'bc-04', name: 'forged-signature-refused', run: forgedSignatureRefused },
  { id: 'bc-05', name: 'amount-mismatch-refused', run: amountMismatchRefused },
  { id: 'bc-06', name: 'settle-failure-refused', run: settleFailureRefused },
  { id: 'bc-07', name: 'cross-session-replay-refused', run: crossSessionReplayRefused },
  { id: 'bc-08', name: 'receipt-forgery-refused', run: receiptForgeryRefused },
  { id: 'bc-09', name: 'facilitator-down-refused', run: facilitatorDownRefused },
];

function freshNonce() {
  return 'bc-' + randomBytes(8).toString('hex');
}

// HTTP helper: records request/response into the session ledger, forwards the
// engine session id so the facilitator can scope fault injections.
export function createHttpContext({ sutBase, ledger, sessionId }) {
  return async function http(method, reqPath, { headers = {}, body } = {}) {
    const url = sutBase + reqPath;
    const safeHeaders = { ...headers };
    if (safeHeaders['x-payment']) safeHeaders['x-payment'] = '<payment header>';
    if (safeHeaders['x-settle-receipt']) safeHeaders['x-settle-receipt'] = '<receipt header>';
    ledger.append('request', { method, path: reqPath, headers: safeHeaders });
    const res = await fetch(url, {
      method,
      headers: { 'x-argus-session': sessionId, ...headers },
      body,
      signal: AbortSignal.timeout(15000),
    });
    const text = await res.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      /* non-JSON body */
    }
    ledger.append('response', { status: res.status, body: json ?? text.slice(0, 200) });
    return { status: res.status, body: json };
  };
}

// Fetch a fresh challenge; resource-served-without-payment is a FAIL, missing
// challenge shape is a FAIL, broken SUT is a HARNESS_ERROR.
async function expectChallenge(ctx) {
  const res = await ctx.http('GET', RESOURCE_PATH);
  if (res.status === 200) {
    return { fail: { verdict: 'FAIL', refusal: null, note: 'resource served without payment' } };
  }
  if (res.status !== 402 || !res.body?.x402?.challenge_id) {
    return { fail: { verdict: 'FAIL', refusal: null, note: `expected 402 x402 challenge, got ${res.status}` } };
  }
  return { challenge: res.body.x402 };
}

function buildValidPayment(ctx, challenge, overrides = {}) {
  return buildPayment(ctx.wallet, {
    challenge_id: challenge.challenge_id,
    amount: overrides.amount ?? challenge.amount,
    resource: challenge.resource,
    nonce: overrides.nonce ?? freshNonce(),
  });
}

async function deliver(ctx, payment, extraHeaders = {}) {
  return ctx.http('POST', RESOURCE_PATH, {
    headers: { 'content-type': 'application/json', 'x-payment': encodePaymentHeader(payment), ...extraHeaders },
    body: JSON.stringify({}),
  });
}

const delivered = (res) => res.status === 200 && res.body?.resource === RESOURCE_TOKEN;
const refusalOf = (res) => res.body?.refusal?.code ?? null;

function expectRefusal(res, codes) {
  if (delivered(res)) {
    return { verdict: 'FAIL', refusal: null, note: 'resource delivered despite invalid payment' };
  }
  if (res.status === 402 && codes.includes(refusalOf(res))) {
    return { verdict: 'DOCUMENTED', refusal: { code: refusalOf(res) }, note: null };
  }
  return {
    verdict: 'FAIL',
    refusal: null,
    note: `expected 402 ${codes.join('|')}, got ${res.status}${refusalOf(res) ? ' ' + refusalOf(res) : ''}`,
  };
}

function expectAnyRefusal(res) {
  if (delivered(res)) {
    return { verdict: 'FAIL', refusal: null, note: 'resource delivered despite invalid payment' };
  }
  if ((res.status === 402 || res.status === 503) && refusalOf(res)) {
    return { verdict: 'DOCUMENTED', refusal: { code: refusalOf(res) }, note: null };
  }
  return { verdict: 'FAIL', refusal: null, note: `expected refusal, got ${res.status}` };
}

async function challengeGate(ctx) {
  const res = await ctx.http('GET', RESOURCE_PATH);
  if (res.status === 200) return { verdict: 'FAIL', refusal: null, note: 'resource served without payment' };
  const ch = res.body?.x402;
  if (res.status !== 402 || !ch || !ch.amount || !ch.facilitator_url || !ch.challenge_id) {
    return { verdict: 'FAIL', refusal: null, note: `expected well-formed x402 challenge on 402, got ${res.status}` };
  }
  return { verdict: 'PASS', refusal: null, note: null };
}

async function validPaymentServed(ctx) {
  const c = await expectChallenge(ctx);
  if (c.fail) return c.fail;
  const payment = buildValidPayment(ctx, c.challenge);
  ctx.shared.replayPayment = payment;
  const res = await deliver(ctx, payment);
  if (!delivered(res)) {
    return { verdict: 'FAIL', refusal: null, note: `valid payment not served: ${res.status} ${refusalOf(res) ?? ''}` };
  }
  if (res.body?.settle?.nonce !== payment.nonce) {
    return { verdict: 'FAIL', refusal: null, note: 'settle receipt not bound to payment nonce' };
  }
  return { verdict: 'PASS', refusal: null, note: null };
}

async function replayRefused(ctx) {
  if (!ctx.shared.replayPayment) throw new Error('bc-03 requires bc-02 payment in shared state');
  const res = await deliver(ctx, ctx.shared.replayPayment);
  return expectRefusal(res, ['nonce_reused']);
}

async function forgedSignatureRefused(ctx) {
  const c = await expectChallenge(ctx);
  if (c.fail) return c.fail;
  const payment = buildValidPayment(ctx, c.challenge);
  const sig = Buffer.from(payment.sig_b64, 'base64');
  sig[0] ^= 0xff;
  payment.sig_b64 = sig.toString('base64');
  const res = await deliver(ctx, payment);
  return expectRefusal(res, ['bad_signature']);
}

async function amountMismatchRefused(ctx) {
  const c = await expectChallenge(ctx);
  if (c.fail) return c.fail;
  const payment = buildValidPayment(ctx, c.challenge, { amount: '9999' });
  const res = await deliver(ctx, payment);
  return expectRefusal(res, ['amount_mismatch']);
}

async function settleFailureRefused(ctx) {
  const c = await expectChallenge(ctx);
  if (c.fail) return c.fail;
  const payment = buildValidPayment(ctx, c.challenge);
  await ctx.facilitator.inject('settle_fail');
  const res = await deliver(ctx, payment);
  return expectRefusal(res, ['settle_failed']);
}

async function crossSessionReplayRefused(ctx) {
  if (!ctx.shared.replayPayment) throw new Error('bc-07 requires bc-02 payment in shared state');
  // This session runs under a fresh engine session id — the facilitator nonce
  // store must still catch the replay.
  const res = await deliver(ctx, ctx.shared.replayPayment);
  return expectRefusal(res, ['nonce_reused']);
}

async function receiptForgeryRefused(ctx) {
  const c = await expectChallenge(ctx);
  if (c.fail) return c.fail;
  const payment = buildValidPayment(ctx, c.challenge, { amount: '9999' });
  const forged = Buffer.from(
    JSON.stringify({ settle_id: 'forged-000000', nonce: payment.nonce }),
    'utf8',
  ).toString('base64');
  const res = await deliver(ctx, payment, { 'x-settle-receipt': forged });
  return expectAnyRefusal(res);
}

async function facilitatorDownRefused(ctx) {
  const c = await expectChallenge(ctx);
  if (c.fail) return c.fail;
  const payment = buildValidPayment(ctx, c.challenge);
  await ctx.facilitator.inject('verify_503');
  const res = await deliver(ctx, payment);
  return expectAnyRefusal(res);
}
