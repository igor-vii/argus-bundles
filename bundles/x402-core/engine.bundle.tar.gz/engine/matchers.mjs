// Argus engine — battery matchers. Finalize raw session outcomes into
// registry-verdicts: every DOCUMENTED must carry a known refusal code, every
// verdict must have recorded evidence. Leak guards live inside the scenario
// drivers themselves (delivered-resource checks).
import { REFUSAL_CODES } from './protocol.mjs';

export function applyMatchers(outcome, evidenceLines) {
  if (!Array.isArray(evidenceLines) || evidenceLines.length === 0) {
    return { verdict: 'HARNESS_ERROR', refusal: null, note: 'no evidence recorded' };
  }
  if (outcome.verdict === 'DOCUMENTED') {
    if (!outcome.refusal || !REFUSAL_CODES.includes(outcome.refusal.code)) {
      return { verdict: 'HARNESS_ERROR', refusal: null, note: 'DOCUMENTED without a known refusal code' };
    }
  }
  return outcome;
}
